# Stay Puppet Module for Boxen

Install [Stay](http://cordlessdog.com/stay/), an automatic window sizing manager.

## Usage

```puppet
include stay
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
