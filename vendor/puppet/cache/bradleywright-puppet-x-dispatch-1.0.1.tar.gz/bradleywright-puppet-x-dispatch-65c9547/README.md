# X-Dispatch Puppet Module for Boxen

Install the
[X-Dispatch helper](http://www.dispatchapp.net/faq.html#openDispatchLinksOnMac),
which allows one to open `x-dispatch://` links on the Mac.

## Usage

```puppet
include x-dispatch
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
