# Emacs Keybindings Puppet Module for Boxen

Installs Emacs-like keybindings for OSX. Based on
[this blog post](http://lelf.lu/posts/emacs-keybindings-mac-os-x.html).

## Usage

```puppet
include emacs-keybindings
```

## Required Puppet Modules

* `boxen`
