# Puppet Module for Banshee

This is a module to install [Banshee](http://banshee.fm)

## Usage

```puppet
include banshee
```

## Required Puppet Modules

* `boxen`
