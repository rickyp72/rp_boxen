# MPlayerX Puppet Module for Boxen ![Build Status](https://travis-ci.org/geetarista/puppet-mplayerx.png)

Installs the MPlayerX Mac app.

## Usage

```puppet
include mplayerx
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
